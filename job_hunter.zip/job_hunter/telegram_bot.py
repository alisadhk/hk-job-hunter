# =============================================================
#  Job Hunter - Telegram Notifier
# =============================================================
import requests
from datetime import datetime
from config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID

BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"

def send_message(text: str, parse_mode: str = "HTML") -> bool:
    try:
        resp = requests.post(
            f"{BASE_URL}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": text,
                  "parse_mode": parse_mode, "disable_web_page_preview": False},
            timeout=15
        )
        return resp.status_code == 200
    except Exception:
        return False

def send_job(job: dict) -> bool:
    title   = job.get("title", "بدون عنوان")
    company = job.get("company", "")
    loc     = job.get("location", "")
    snippet = job.get("snippet", "")
    url     = job.get("url") or job.get("link", "")
    source  = job.get("source", "")
    keyword = job.get("keyword", "")
    dork    = job.get("dork", "")
    now     = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = ["🔔 <b>وظيفة جديدة وجدت!</b>", ""]
    lines.append(f"📌 <b>المسمى:</b> {title}")
    if company:
        lines.append(f"🏢 <b>الشركة:</b> {company}")
    if loc:
        lines.append(f"📍 <b>الموقع:</b> {loc}")
    if snippet:
        lines.append(f"📝 <b>التفاصيل:</b> {snippet[:300]}{'...' if len(snippet)>300 else ''}")
    lines.append(f"🔍 <b>الكلمة المفتاحية:</b> {keyword}")
    lines.append(f"⚙️ <b>المصدر:</b> {source}")
    lines.append(f"🕐 <b>وقت الاكتشاف:</b> {now}")
    if url:
        lines.append(f"\n🔗 <a href='{url}'>فتح الرابط</a>")
    if dork:
        lines.append(f"\n<code>🔎 {dork[:200]}</code>")

    return send_message("\n".join(lines))

def send_summary(total_found: int, total_sent: int, keywords: list, source: str):
    now  = datetime.now().strftime("%Y-%m-%d %H:%M")
    text = (
        f"📊 <b>تقرير البحث</b>\n\n"
        f"🕐 الوقت: {now}\n"
        f"⚙️ المصدر: {source}\n"
        f"🔍 الكلمات: {len(keywords)}\n"
        f"📥 إجمالي النتائج: {total_found}\n"
        f"📤 وظائف جديدة أُرسلت: {total_sent}\n"
        f"🔁 مكررة (تجاهل): {total_found - total_sent}"
    )
    send_message(text)

def send_error(msg: str):
    send_message(f"⛔ <b>خطأ في Job Hunter:</b>\n{msg}")

def test_connection() -> bool:
    try:
        resp = requests.get(f"{BASE_URL}/getMe", timeout=10)
        return resp.status_code == 200
    except Exception:
        return False
