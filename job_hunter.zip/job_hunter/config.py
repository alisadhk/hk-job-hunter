# =============================================================
#  Job Hunter - Config
# =============================================================

TELEGRAM_TOKEN  = "8765886011:AAG537FJ6nmbowg8K_e2eEsSDnBnCU2vBXM"
TELEGRAM_CHAT_ID = "8234113236"

GOOGLE_API_KEY  = "AIzaSyBcRfvE2Gcdr0DNZQhQTWJmInq9csQAIJg"
GOOGLE_CX       = "e763eed2e84bf4f87"

JSEARCH_API_KEY = ""   # اختياري - ضع مفتاحك هنا

# ---- الكلمات المفتاحية الافتراضية ----
DEFAULT_KEYWORDS = [
    "NOC Engineer",
    "NOC Team Leader",
    "Network Engineer",
    "Network Administrator",
    "Network Operations",
    "NOC Analyst",
    "Network Technician",
    "ONC Engineer",
]

# ---- كل احتمالات بغداد/العراق ----
LOCATION_VARIANTS = [
    "Baghdad", "Baghdad Iraq", "Iraq Baghdad",
    "Baghdad, Iraq", "Iraq, Baghdad",
    "Baghdad - Iraq", "Iraq - Baghdad",
    "بغداد", "العراق", "بغداد العراق",
    "العراق بغداد", "بغداد، العراق",
    "العراق، بغداد", "بغداد - العراق",
    "Baghdad العراق", "Iraq بغداد",
    "بغداد Iraq", "العراق Baghdad",
]

# ---- إعدادات البحث ----
RESULTS_PER_QUERY   = 10   # نتائج لكل query
SEARCH_INTERVAL_HRS = 3    # الفاصل الزمني الافتراضي (ساعات)
