# HK Job Hunter 🔍

برنامج بحث تلقائي عن وظائف في بغداد/العراق على LinkedIn مع إشعارات Telegram.

## هيكل المشروع

```
job_hunter/
├── main.py              ← الواجهة الرسومية (PyQt6)
├── config.py            ← إعدادات + API keys
├── search_engine.py     ← المحرك الرئيسي للبحث
├── google_searcher.py   ← Google Custom Search + Dork builder
├── telegram_bot.py      ← إرسال الإشعارات
├── dedup_manager.py     ← منع التكرار + السجل
├── requirements.txt     ← المكتبات المطلوبة
└── data/
    ├── seen_jobs.json   ← الوظائف المُرسلة مسبقاً
    ├── search_log.json  ← سجل عمليات البحث
    └── google_quota.json← مراقبة استهلاك Google API
```

## التثبيت

```bash
# 1. إنشاء بيئة افتراضية (اختياري لكن مستحسن)
python -m venv venv
venv\Scripts\activate   # Windows
source venv/bin/activate # Linux/Mac

# 2. تثبيت المكتبات
pip install -r requirements.txt

# 3. تشغيل البرنامج
python main.py
```

## الإعدادات (config.py)

ضع مفاتيحك في ملف `config.py`:

```python
TELEGRAM_TOKEN   = "توكن البوت"
TELEGRAM_CHAT_ID = "chat id الخاص بك"
GOOGLE_API_KEY   = "مفتاح Google Custom Search"
GOOGLE_CX        = "Search Engine ID"
```

## الاستخدام

1. شغّل `python main.py`
2. أضف/عدّل الكلمات المفتاحية
3. اختر النطاق الزمني (يوم / أسبوع / شهر / تلقائي)
4. اضغط ▶ ابدأ البحث
5. النتائج الجديدة تُرسل تلقائياً لـ Telegram

## ملاحظات API

- Google Custom Search: 100 بحث يومي مجاناً
- البرنامج يتابع الاستهلاك تلقائياً ويعرضه في الـ Log
- عند نفاد الـ quota يتوقف Google ويُسجّل في الـ Log
