# =============================================================
#  Job Hunter - Google Custom Search + Dork Generator
# =============================================================
import requests, json, os
from datetime import datetime, timedelta
from config import GOOGLE_API_KEY, GOOGLE_CX, LOCATION_VARIANTS, RESULTS_PER_QUERY

QUOTA_FILE = os.path.join(os.path.dirname(__file__), "data", "google_quota.json")

# ---- Quota Tracking ----
def _load_quota():
    if os.path.exists(QUOTA_FILE):
        with open(QUOTA_FILE, "r") as f:
            return json.load(f)
    return {"date": "", "used": 0}

def _save_quota(data):
    os.makedirs(os.path.dirname(QUOTA_FILE), exist_ok=True)
    with open(QUOTA_FILE, "w") as f:
        json.dump(data, f)

def get_quota_status():
    q = _load_quota()
    today = datetime.now().strftime("%Y-%m-%d")
    if q["date"] != today:
        return {"date": today, "used": 0, "remaining": 100}
    return {"date": today, "used": q["used"], "remaining": max(0, 100 - q["used"])}

def _increment_quota():
    today = datetime.now().strftime("%Y-%m-%d")
    q = _load_quota()
    if q["date"] != today:
        q = {"date": today, "used": 0}
    q["used"] += 1
    _save_quota(q)

def is_quota_available():
    s = get_quota_status()
    return s["remaining"] > 0

# ---- Dork Builder ----
def build_dork(keyword: str, date_range: str = "week") -> str:
    loc_sample = [
        '"Baghdad"', '"بغداد"', '"Baghdad Iraq"',
        '"بغداد العراق"', '"Iraq"', '"العراق"'
    ]
    loc_str = " OR ".join(loc_sample[:4])

    hiring_terms = (
        '"hiring" OR "we are hiring" OR "مطلوب" OR '
        '"وظيفة" OR "job" OR "vacancy" OR "فرصة عمل" OR "career"'
    )

    date_suffix = ""
    if date_range == "day":
        date_suffix = f' after:{(datetime.now()-timedelta(days=1)).strftime("%Y-%m-%d")}'
    elif date_range == "week":
        date_suffix = f' after:{(datetime.now()-timedelta(weeks=1)).strftime("%Y-%m-%d")}'
    elif date_range == "month":
        date_suffix = f' after:{(datetime.now()-timedelta(days=30)).strftime("%Y-%m-%d")}'

    dork = f'"{keyword}" ({loc_str}) ({hiring_terms}){date_suffix}'
    return dork

def build_all_dorks(keywords: list, date_range: str = "week") -> list:
    dorks = []
    for kw in keywords:
        dorks.append({
            "keyword": kw,
            "query":   build_dork(kw, date_range)
        })
    return dorks

# ---- Search ----
def search_google(keyword: str, date_range: str = "week", log_cb=None) -> list:
    if not is_quota_available():
        if log_cb:
            log_cb("google", "⛔ Google API quota استُنفد لهذا اليوم (100/100)", "warning")
        return []

    dork = build_dork(keyword, date_range)
    url  = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": GOOGLE_API_KEY,
        "cx":  GOOGLE_CX,
        "q":   dork,
        "num": RESULTS_PER_QUERY,
    }

    try:
        resp = requests.get(url, params=params, timeout=15)
        _increment_quota()

        if resp.status_code == 429:
            if log_cb:
                log_cb("google", "⛔ Google API: Rate limit (429)", "error")
            return []

        if resp.status_code != 200:
            if log_cb:
                log_cb("google", f"⛔ Google API خطأ: {resp.status_code} - {resp.text[:100]}", "error")
            return []

        data = resp.json()
        items = data.get("items", [])
        results = []
        for item in items:
            results.append({
                "title":   item.get("title", ""),
                "url":     item.get("link", ""),
                "snippet": item.get("snippet", ""),
                "source":  "Google Search",
                "keyword": keyword,
                "dork":    dork,
            })

        quota = get_quota_status()
        if log_cb:
            log_cb("google",
                   f"✅ Google: '{keyword}' → {len(results)} نتيجة | Quota: {quota['used']}/100",
                   "success")
        return results

    except requests.exceptions.Timeout:
        if log_cb:
            log_cb("google", f"⏱️ Google timeout للكلمة: {keyword}", "warning")
        return []
    except Exception as e:
        if log_cb:
            log_cb("google", f"⛔ Google استثناء: {str(e)}", "error")
        return []

def search_all_keywords(keywords: list, date_range: str = "week", log_cb=None) -> list:
    all_results = []
    for kw in keywords:
        if not is_quota_available():
            if log_cb:
                log_cb("google", "⛔ Google quota نفد، إيقاف البحث بـ Google", "warning")
            break
        results = search_google(kw, date_range, log_cb)
        all_results.extend(results)
    return all_results
