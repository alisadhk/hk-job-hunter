# =============================================================
#  Job Hunter - Search Orchestrator
# =============================================================
from google_searcher import search_all_keywords, build_all_dorks, get_quota_status
from dedup_manager  import is_new, mark_seen, log_search
from telegram_bot   import send_job, send_summary, send_error

def run_search(keywords: list, date_range: str = "week",
               log_cb=None, result_cb=None, stop_flag=None):
    """
    المحرك الرئيسي للبحث.
    log_cb(source, msg, level)   → تحديث الـ Log في الواجهة
    result_cb(job)               → إضافة نتيجة للجدول
    stop_flag()                  → يرجع True إذا طُلب الإيقاف
    """
    total_found = 0
    total_sent  = 0

    def _log(src, msg, lvl="info"):
        if log_cb:
            log_cb(src, msg, lvl)

    _log("system", f"🚀 بدء البحث | النطاق الزمني: {date_range} | كلمات: {len(keywords)}", "success")

    # ---- Google Custom Search ----
    quota = get_quota_status()
    _log("google", f"📊 Google Quota: {quota['used']}/100 مستخدم، {quota['remaining']} متبقي", "info")

    if quota["remaining"] > 0:
        results = search_all_keywords(keywords, date_range, log_cb=_log)
    else:
        _log("google", "⛔ Google quota نفد — تم تخطي Google Search", "warning")
        results = []

    total_found += len(results)

    for job in results:
        if stop_flag and stop_flag():
            _log("system", "🛑 تم إيقاف البحث بطلب المستخدم", "warning")
            break

        if is_new(job):
            mark_seen(job)
            ok = send_job(job)
            if ok:
                total_sent += 1
                _log("telegram", f"📤 أُرسل: {job.get('title','')[:60]}", "success")
            else:
                _log("telegram", f"⛔ فشل إرسال: {job.get('title','')[:60]}", "error")
            if result_cb:
                result_cb(job)
        else:
            _log("system", f"🔁 مكرر، تجاهل: {job.get('title','')[:60]}", "info")

        log_search("Google", job.get("keyword",""), 1,
                   1 if is_new(job) else 0, "ok")

    # ---- ملخص ----
    _log("system",
         f"✅ انتهى البحث | إجمالي: {total_found} | جديد: {total_sent} | مكرر: {total_found-total_sent}",
         "success")
    send_summary(total_found, total_sent, keywords, "Google Custom Search")

    return {"found": total_found, "sent": total_sent}
